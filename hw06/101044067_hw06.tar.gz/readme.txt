Parsing standart: (<function>)^(<power>)
example: (x^2)^(1/3)